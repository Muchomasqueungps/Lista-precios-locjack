import React, { ReactNode } from 'react';
import { CheckCircle } from 'lucide-react';

interface StepCardProps {
  number: number;
  title: string;
  description: string;
  isActive: boolean;
  isCompleted: boolean;
  children: ReactNode;
}

export const StepCard: React.FC<StepCardProps> = ({ 
  number, 
  title, 
  description, 
  isActive, 
  isCompleted, 
  children 
}) => {
  return (
    <div className={`mb-6 border rounded-xl transition-all duration-300 ${
      isActive 
        ? 'bg-white border-blue-500 shadow-lg ring-1 ring-blue-500' 
        : isCompleted 
          ? 'bg-slate-50 border-green-200' 
          : 'bg-white border-gray-200 opacity-60'
    }`}>
      <div className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className={`flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm ${
            isCompleted ? 'bg-green-100 text-green-700' : isActive ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
          }`}>
            {isCompleted ? <CheckCircle size={18} /> : number}
          </div>
          <div>
            <h3 className={`font-semibold text-lg ${isActive ? 'text-slate-900' : 'text-slate-600'}`}>
              {title}
            </h3>
            <p className="text-sm text-slate-500">{description}</p>
          </div>
        </div>
        
        <div className={`${!isActive && !isCompleted ? 'hidden' : 'block'}`}>
          {children}
        </div>
      </div>
    </div>
  );
};