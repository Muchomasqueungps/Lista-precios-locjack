import { PricingData, CompatibilityMatrix } from './types';

export const pricingData: PricingData = {
  planes: [
    {
      concepto: 'Loc-Jack Track Anual',
      descripcion: 'GPS con plataforma web + app móvil',
      precioBase: 3500,
      moneda: 'MXN',
      tipo: 'Anual',
      destacado: true
    },
    {
      concepto: 'Loc-Jack Track Renovación',
      descripcion: 'Renovación año 2 en adelante',
      precioBase: 3000,
      moneda: 'MXN',
      tipo: 'Anual'
    },
    {
      concepto: 'Loc-Jack Track Mensual',
      descripcion: 'Plan mensual con plataforma + app',
      precioBase: 250,
      moneda: 'MXN',
      tipo: 'Mensual'
    },
    {
      concepto: 'Renta de Equipo Track',
      descripcion: 'Renta mensual del dispositivo GPS',
      precioBase: 50,
      moneda: 'MXN',
      tipo: 'Mensual'
    },
    {
      concepto: 'Loc-Jack Safe Anual',
      descripcion: 'GPS solo con app móvil',
      precioBase: 3000,
      moneda: 'MXN',
      tipo: 'Anual',
      destacado: true
    },
    {
      concepto: 'Paquete Básico',
      descripcion: 'Cámara externa + Botón pánico',
      precioBase: 60,
      moneda: 'USD',
      tipo: 'Mensual'
    },
    {
      concepto: 'Paquete Plus',
      descripcion: 'Cámara ext + int + Botón pánico',
      precioBase: 60,
      moneda: 'USD',
      tipo: 'Mensual'
    },
    {
      concepto: 'Paquete Platinum',
      descripcion: 'Cámara ext + int + Botón + IA',
      precioBase: 60,
      moneda: 'USD',
      tipo: 'Mensual'
    }
  ],
  costosUnicos: {
    servicios: [
      {
        concepto: 'Instalación Tijuana',
        descripcion: 'Para planes Track y Safe',
        precioBase: 500,
        moneda: 'MXN',
        tipo: 'Único',
        nota: 'GRATIS en 5+ unidades'
      },
      {
        concepto: 'Instalación Track Mensual',
        descripcion: 'Solo para plan mensual',
        precioBase: 900,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Instalación Básico (USD)',
        descripcion: 'Paquete Básico en Tijuana',
        precioBase: 50,
        moneda: 'USD',
        tipo: 'Único'
      },
      {
        concepto: 'Instalación Plus (USD)',
        descripcion: 'Paquete Plus en Tijuana',
        precioBase: 55,
        moneda: 'USD',
        tipo: 'Único'
      },
      {
        concepto: 'Instalación Platinum (USD)',
        descripcion: 'Paquete Platinum en Tijuana',
        precioBase: 60,
        moneda: 'USD',
        tipo: 'Único'
      },
      {
        concepto: 'SIM de Datos',
        descripcion: 'Tarjeta SIM individual',
        precioBase: 150,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Programación Equipo Empresa',
        descripcion: 'Para plan empresarial 4G',
        precioBase: 600,
        moneda: 'MXN',
        tipo: 'Único'
      }
    ],
    depositos: [
      {
        concepto: 'Depósito Básico',
        descripcion: 'Garantía reembolsable 70%',
        precioBase: 135,
        moneda: 'USD',
        tipo: 'Único'
      },
      {
        concepto: 'Depósito Plus',
        descripcion: 'Garantía reembolsable 70%',
        precioBase: 165,
        moneda: 'USD',
        tipo: 'Único'
      },
      {
        concepto: 'Depósito Platinum',
        descripcion: 'Garantía reembolsable 70%',
        precioBase: 205,
        moneda: 'USD',
        tipo: 'Único'
      }
    ],
    robo: [
      {
        concepto: 'Robo Equipo Básico',
        descripcion: 'Cargo por robo de equipo',
        precioBase: 300,
        moneda: 'USD',
        tipo: 'Único'
      },
      {
        concepto: 'Robo Equipo Plus',
        descripcion: 'Cargo por robo de equipo',
        precioBase: 350,
        moneda: 'USD',
        tipo: 'Único'
      },
      {
        concepto: 'Robo Equipo Platinum',
        descripcion: 'Cargo por robo de equipo',
        precioBase: 400,
        moneda: 'USD',
        tipo: 'Único'
      }
    ],
    equipo: [
      {
        concepto: 'Equipo GPS Básico',
        descripcion: 'Dispositivo GPS 4G básico',
        precioBase: 1000,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Equipo GPS Avanzado Ruptela',
        descripcion: 'Dispositivo GPS 4G avanzado',
        precioBase: 2000,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Equipo GPS Personal',
        descripcion: 'GPS portátil personal',
        precioBase: 2000,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Equipo GPS con Magneto',
        descripcion: 'GPS con instalación magnética',
        precioBase: 2000,
        moneda: 'MXN',
        tipo: 'Único'
      }
    ]
  },
  addons: {
    accesorios: [
      {
        concepto: 'Deshabilitador de Motor (Relay)',
        descripcion: 'HKVF4 - Incluido en contratación',
        precioBase: 200,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Botón de Pánico',
        descripcion: 'Incluido en contratación',
        precioBase: 200,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Sensor de Temperatura',
        descripcion: 'Monitoreo de temperatura',
        precioBase: 1950,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Sensor de Combustible',
        descripcion: 'Monitoreo nivel combustible',
        precioBase: 6480,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Anti-Jammer',
        descripcion: 'Protección contra inhibidores',
        precioBase: 1900,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Sensor Apertura Puertas',
        descripcion: 'Detección apertura puertas',
        precioBase: 1000,
        moneda: 'MXN',
        tipo: 'Único'
      }
    ],
    servicios: [
      {
        concepto: 'Relay - Instalación Posterior',
        descripcion: 'Si se instala después',
        precioBase: 600,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Botón Pánico - Instalación Posterior',
        descripcion: 'Si se instala después',
        precioBase: 600,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Sensor Temperatura - Instalación',
        descripcion: 'Instalación local',
        precioBase: 1200,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Sensor Combustible - Instalación',
        descripcion: 'Instalación local',
        precioBase: 3000,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Anti-Jammer - Instalación',
        descripcion: 'Instalación local',
        precioBase: 600,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Sensor Puertas - Instalación',
        descripcion: 'Instalación local',
        precioBase: 1200,
        moneda: 'MXN',
        tipo: 'Único'
      },
      {
        concepto: 'Revisión en Campo',
        descripcion: 'Mantenimiento empresarial',
        precioBase: 200,
        moneda: 'MXN',
        tipo: 'Único'
      }
    ]
  }
};

export const compatibilityMatrix: CompatibilityMatrix = {
  'GPS Básico': {
    accesorios: ['Relay', 'Botón Pánico', 'Anti-Jammer'],
    limitaciones: 'No soporta sensores avanzados'
  },
  'GPS Avanzado (Ruptela)': {
    accesorios: ['Relay', 'Botón Pánico', 'Sensor Temperatura', 'Sensor Combustible', 'Anti-Jammer', 'Sensor Puertas'],
    limitaciones: 'Compatible con todos los accesorios'
  },
  'GPS Personal': {
    accesorios: ['Botón Pánico'],
    limitaciones: 'Solo botón de pánico por diseño portátil'
  },
  'GPS con Magneto': {
    accesorios: ['Anti-Jammer'],
    limitaciones: 'Instalación limitada por diseño magnético'
  },
  'Paquete Básico': {
    accesorios: ['Cámara Externa', 'Botón Pánico (incluido)'],
    limitaciones: 'No incluye cámara interna ni IA'
  },
  'Paquete Plus': {
    accesorios: ['Cámara Externa (incluida)', 'Cámara Interna (incluida)', 'Botón Pánico (incluido)'],
    limitaciones: 'No incluye IA'
  },
  'Paquete Platinum': {
    accesorios: ['Cámara Externa (incluida)', 'Cámara Interna (incluida)', 'Botón Pánico (incluido)', 'IA (incluida)'],
    limitaciones: 'Paquete completo'
  }
};