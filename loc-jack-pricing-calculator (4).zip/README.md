# Loc-Jack Pricing Calculator

Sistema de cálculo de precios estructural basado en el modelo psicopedagógico "Loc-Jack".

## Características

- Matriz de compatibilidad para equipos GPS y accesorios.
- Niveles de precios (Base, Mínimo, Sugerido).
- Generación de cotizaciones.
- Panel de Administrador para editar precios e inventario.

## Instalación

1. `npm install`
2. `npm run dev`

## Construcción para Producción

1. Ejecuta `npm run build`.
2. La carpeta `dist` contendrá los archivos estáticos listos para subir a tu servidor.