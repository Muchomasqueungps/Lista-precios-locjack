import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  base: './', // IMPORTANTE: Esto permite que la app funcione en carpetas compartidas o subdominios en tu hosting
  server: {
    host: true, // Expose to network
  }
})