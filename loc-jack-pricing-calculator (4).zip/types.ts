export interface PricingItem {
  concepto: string;
  descripcion: string;
  precioBase: number;
  moneda: 'MXN' | 'USD';
  tipo: 'Mensual' | 'Anual' | 'Único';
  destacado?: boolean;
  nota?: string;
}

export enum PricingLevel {
  LEVEL_1_FLOOR = 'LEVEL_1_FLOOR',
  LEVEL_2_MIN = 'LEVEL_2_MIN',
  LEVEL_3_STD = 'LEVEL_3_STD',
}

export interface PricingData {
  planes: PricingItem[];
  costosUnicos: {
    servicios: PricingItem[];
    depositos: PricingItem[];
    robo: PricingItem[];
    equipo: PricingItem[];
  };
  addons: {
    accesorios: PricingItem[];
    servicios: PricingItem[];
  };
}

export interface CompatibilityItem {
  accesorios: string[];
  limitaciones: string;
}

export interface CompatibilityMatrix {
  [key: string]: CompatibilityItem;
}