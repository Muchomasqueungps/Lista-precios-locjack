import React, { useState, useEffect } from 'react';
import { Search, TrendingUp, AlertCircle, Package, Wrench, Shield, Zap, Lock, Unlock, Save, RotateCcw, X, Check, Plus, Trash2, FileText } from 'lucide-react';
import { pricingData as defaultData, compatibilityMatrix } from './data';
import { PricingItem, PricingData } from './types';

// Constants for markup
const IVA_RATE = 0.16;
const MARKUP = {
  minimo: 0.10,
  sugerido: 0.25
};

// --- Subcomponents for Viewer ---

const PriceCell = ({ price, showPricing, showIVA, calcPrice }: { price: number; showPricing: string; showIVA: boolean, calcPrice: (p: number, m?: number) => string }) => {
  if (price === 0) {
    return <span className="text-gray-400 text-sm">Consultar</span>;
  }

  const getPrice = (markup = 0) => {
    const basePrice = showIVA ? price * (1 + IVA_RATE) : price;
    return (basePrice * (1 + markup)).toFixed(2);
  };

  if (showPricing === 'base') {
    return (
      <div className="text-right font-mono">
        <div className="font-semibold">${calcPrice(price)}</div>
      </div>
    );
  }

  if (showPricing === 'minimo') {
    return (
      <div className="text-right font-mono">
        <div className="text-xs text-gray-500 line-through">${calcPrice(price)}</div>
        <div className="font-semibold text-orange-600">${getPrice(MARKUP.minimo)}</div>
      </div>
    );
  }

  if (showPricing === 'sugerido') {
    return (
      <div className="text-right font-mono">
        <div className="text-xs text-gray-500 line-through">${calcPrice(price)}</div>
        <div className="font-semibold text-green-600">${getPrice(MARKUP.sugerido)}</div>
      </div>
    );
  }

  return (
    <div className="text-right font-mono text-xs">
      <div className="text-gray-600">Base: ${calcPrice(price)}</div>
      <div className="text-orange-600">Mín: ${getPrice(MARKUP.minimo)}</div>
      <div className="text-green-600 font-semibold">Sug: ${getPrice(MARKUP.sugerido)}</div>
    </div>
  );
};

const TableSection = ({ 
  title, 
  data, 
  color, 
  icon: Icon, 
  subcategory, 
  searchTerm,
  showPricing,
  showIVA,
  calcPrice
}: { 
  title?: string; 
  data: PricingItem[]; 
  color: string; 
  icon?: any; 
  subcategory?: string; 
  searchTerm: string;
  showPricing: string;
  showIVA: boolean;
  calcPrice: (p: number, m?: number) => string;
}) => {
  
  const filtered = data.filter(item => 
    item.concepto.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.descripcion.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  if (filtered.length === 0) return null;

  return (
    <div className="mb-4">
      <div className={`flex items-center gap-2 mb-2 pb-1 border-b ${color}`}>
        {Icon && <Icon className="w-4 h-4" />}
        <h3 className="text-sm font-bold">{subcategory || title}</h3>
      </div>
      <div className="overflow-x-auto pb-2">
        <table className="w-full text-sm min-w-[600px]">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left p-2 font-semibold text-xs">Concepto</th>
              <th className="text-left p-2 font-semibold text-xs">Descripción</th>
              <th className="text-center p-2 font-semibold text-xs">Tipo</th>
              <th className="text-center p-2 font-semibold text-xs">Moneda</th>
              <th className="text-right p-2 font-semibold text-xs">Precio</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((item, idx) => (
              <tr 
                key={idx}
                className={`border-b hover:bg-gray-50 ${
                  item.destacado ? 'bg-blue-50 font-semibold' : ''
                }`}
              >
                <td className="p-2 text-xs">
                  {item.concepto}
                  {item.nota && (
                    <span className="ml-2 text-xs text-green-600 font-medium">
                      ({item.nota})
                    </span>
                  )}
                </td>
                <td className="p-2 text-gray-600 text-xs">{item.descripcion}</td>
                <td className="p-2 text-center">
                  <span className={`px-2 py-0.5 rounded text-xs ${
                    item.tipo === 'Mensual' ? 'bg-blue-100 text-blue-700' :
                    item.tipo === 'Anual' ? 'bg-green-100 text-green-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {item.tipo}
                  </span>
                </td>
                <td className="p-2 text-center font-mono text-xs">{item.moneda}</td>
                <td className="p-2">
                  <PriceCell 
                    price={item.precioBase} 
                    showPricing={showPricing} 
                    showIVA={showIVA} 
                    calcPrice={calcPrice} 
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// --- Admin Components ---

const LoginModal = ({ onClose, onLogin }: { onClose: () => void, onLogin: (pass: string) => void }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'Locjack') {
      onLogin(password);
    } else {
      setError(true);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-sm">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold flex items-center gap-2">
            <Lock className="w-5 h-5 text-blue-600" />
            Acceso Admin
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Contraseña</label>
            <input 
              type="password" 
              className={`w-full p-3 border rounded bg-white focus:outline-none focus:ring-2 ${error ? 'border-red-500 ring-red-200' : 'border-gray-300 ring-blue-200'}`}
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(false); }}
              placeholder="Ingrese contraseña"
              autoFocus
            />
            {error && <p className="text-xs text-red-500 mt-1">Contraseña incorrecta</p>}
          </div>
          <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded font-medium hover:bg-blue-700">
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
};

const AdminSectionEditor = ({ 
  title, 
  items, 
  onUpdateList 
}: { 
  title: string; 
  items: PricingItem[]; 
  onUpdateList: (newItems: PricingItem[]) => void;
}) => {
  
  const handleFieldChange = (index: number, field: keyof PricingItem, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    onUpdateList(newItems);
  };

  const handleDelete = (index: number) => {
    if (window.confirm('¿Estás seguro de eliminar este elemento?')) {
      const newItems = items.filter((_, i) => i !== index);
      onUpdateList(newItems);
    }
  };

  const handleDeleteAll = () => {
    if (window.confirm(`¿Estás SEGURO de vaciar toda la lista de "${title}"? Esta acción no se puede deshacer.`)) {
      onUpdateList([]);
    }
  };

  const handleAdd = () => {
    const newItem: PricingItem = {
      concepto: 'Nuevo Concepto',
      descripcion: 'Descripción...',
      precioBase: 0,
      moneda: 'MXN',
      tipo: 'Único'
    };
    onUpdateList([...items, newItem]);
  };

  return (
    <div className="mb-8 border rounded-lg overflow-hidden bg-white shadow-sm">
      <div className="bg-gray-50 px-4 py-3 border-b flex justify-between items-center">
        <h3 className="font-bold text-gray-800 text-sm md:text-base">{title}</h3>
        <div className="flex gap-2">
          {items.length > 0 && (
            <button 
              type="button"
              onClick={handleDeleteAll}
              className="flex items-center gap-1 bg-white border border-red-200 text-red-600 px-3 py-1.5 rounded text-xs hover:bg-red-50 transition-colors"
              title="Borrar todos los elementos de esta lista"
            >
              <Trash2 className="w-3 h-3" /> Vaciar
            </button>
          )}
          <button 
            type="button"
            onClick={handleAdd}
            className="flex items-center gap-1 bg-blue-600 text-white px-3 py-1.5 rounded text-xs hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-3 h-3" /> Agregar
          </button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-xs min-w-[800px]">
          <thead className="bg-gray-100 text-gray-600">
            <tr>
              <th className="p-2 text-left w-1/4">Concepto</th>
              <th className="p-2 text-left w-1/4">Descripción</th>
              <th className="p-2 text-left w-24">Tipo</th>
              <th className="p-2 text-left w-20">Moneda</th>
              <th className="p-2 text-right w-24">Precio Base</th>
              <th className="p-2 text-center w-16">Acción</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 ? (
              <tr>
                <td colSpan={6} className="p-8 text-center text-gray-400 italic">
                  Esta lista está vacía. Agrega un nuevo elemento.
                </td>
              </tr>
            ) : (
              items.map((item, idx) => (
                <tr key={idx} className="border-b hover:bg-blue-50">
                  <td className="p-2">
                    <input 
                      type="text" 
                      value={item.concepto}
                      onChange={(e) => handleFieldChange(idx, 'concepto', e.target.value)}
                      className="w-full p-2 border border-gray-200 rounded bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                  </td>
                  <td className="p-2">
                    <input 
                      type="text" 
                      value={item.descripcion}
                      onChange={(e) => handleFieldChange(idx, 'descripcion', e.target.value)}
                      className="w-full p-2 border border-gray-200 rounded bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                  </td>
                  <td className="p-2">
                    <select 
                      value={item.tipo}
                      onChange={(e) => handleFieldChange(idx, 'tipo', e.target.value)}
                      className="w-full p-2 border border-gray-200 rounded focus:border-blue-500 outline-none bg-white"
                    >
                      <option value="Mensual">Mensual</option>
                      <option value="Anual">Anual</option>
                      <option value="Único">Único</option>
                    </select>
                  </td>
                  <td className="p-2">
                     <select 
                      value={item.moneda}
                      onChange={(e) => handleFieldChange(idx, 'moneda', e.target.value)}
                      className="w-full p-2 border border-gray-200 rounded focus:border-blue-500 outline-none bg-white"
                    >
                      <option value="MXN">MXN</option>
                      <option value="USD">USD</option>
                    </select>
                  </td>
                  <td className="p-2">
                    <input 
                      type="number" 
                      value={item.precioBase}
                      onChange={(e) => handleFieldChange(idx, 'precioBase', Number(e.target.value))}
                      className="w-full p-2 text-right border border-gray-200 rounded bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                    />
                  </td>
                  <td className="p-2 text-center">
                    <button 
                      type="button"
                      onClick={() => handleDelete(idx)}
                      className="text-red-500 bg-red-50 hover:bg-red-600 hover:text-white transition-all p-2 rounded shadow-sm"
                      title="Eliminar elemento"
                    >
                      <Trash2 className="w-4 h-4 pointer-events-none" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};


// --- Matrix Helper ---
const matrixColumns = [
  { label: 'Paro de Motor', keyword: 'Relay' },
  { label: 'Botón Pánico', keyword: 'Pánico' },
  { label: 'Anti-Jammer', keyword: 'Jammer' },
  { label: 'Temperatura', keyword: 'Temperatura' },
  { label: 'Combustible', keyword: 'Combustible' },
  { label: 'Puertas', keyword: 'Puertas' },
  { label: 'Video / Cámaras', keyword: 'Cámara' },
  { label: 'IA (Fatiga/Distracción)', keyword: 'IA' },
];

const checkCompatibility = (accessories: string[], keyword: string) => {
  return accessories.some(acc => acc.includes(keyword));
};

// --- Main Component ---

export default function App() {
  // State
  const [data, setData] = useState<PricingData>(defaultData);
  const [showIVA, setShowIVA] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPricing, setShowPricing] = useState('sugerido');
  const [activeTab, setActiveTab] = useState('precios');
  
  // Auth State
  const [isAdmin, setIsAdmin] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  // Load from local storage on mount
  useEffect(() => {
    const savedData = localStorage.getItem('locjack_pricing_data');
    if (savedData) {
      try {
        setData(JSON.parse(savedData));
      } catch (e) {
        console.error("Error loading saved data", e);
      }
    }
  }, []);

  // Helpers
  const calcPrice = (price: number, markup = 0) => {
    if (price === 0) return '—';
    const basePrice = showIVA ? price * (1 + IVA_RATE) : price;
    const finalPrice = basePrice * (1 + markup);
    return finalPrice.toFixed(2);
  };

  // Helper to deep update state and persist
  const updateDataState = (newData: PricingData) => {
    setData(newData);
    localStorage.setItem('locjack_pricing_data', JSON.stringify(newData));
  };

  const resetToDefaults = () => {
    if (window.confirm('¿Estás seguro de restaurar todos los precios originales? Se perderán los cambios personalizados.')) {
      setData(defaultData);
      localStorage.removeItem('locjack_pricing_data');
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-3 md:p-6 bg-white min-h-screen">
      {showLogin && (
        <LoginModal 
          onClose={() => setShowLogin(false)} 
          onLogin={(pass) => {
            setIsAdmin(true);
            setShowLogin(false);
            setActiveTab('admin');
          }} 
        />
      )}

      {/* Header */}
      <div className="mb-6 pb-4 border-b-4 border-blue-600 flex flex-col md:flex-row md:justify-between md:items-end gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-1">Loc-Jack - Lista de Precios 2025</h1>
          <p className="text-sm text-gray-600">Guía de precios estructurada para equipo de ventas</p>
        </div>
        <button 
          onClick={() => isAdmin ? setIsAdmin(false) : setShowLogin(true)}
          className={`flex items-center justify-center gap-2 px-3 py-2 md:py-1.5 rounded-full text-xs font-bold transition-colors w-full md:w-auto ${
            isAdmin ? 'bg-red-100 text-red-700 hover:bg-red-200' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          {isAdmin ? <><Unlock className="w-3 h-3" /> Admin Activo</> : <><Lock className="w-3 h-3" /> Acceso Admin</>}
        </button>
      </div>

      {/* Tabs */}
      <div className="mb-6 flex gap-2 border-b-2 border-gray-200 overflow-x-auto pb-1">
        <button
          onClick={() => setActiveTab('precios')}
          className={`px-4 py-2 font-semibold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'precios' 
              ? 'border-b-2 border-blue-600 text-blue-600 -mb-0.5' 
              : 'text-gray-600 hover:text-blue-600'
          }`}
        >
          📋 Lista de Precios
        </button>
        <button
          onClick={() => setActiveTab('compatibilidad')}
          className={`px-4 py-2 font-semibold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'compatibilidad' 
              ? 'border-b-2 border-blue-600 text-blue-600 -mb-0.5' 
              : 'text-gray-600 hover:text-blue-600'
          }`}
        >
          🔧 Compatibilidad
        </button>
        <button
          onClick={() => setActiveTab('cotizacion')}
          className={`px-4 py-2 font-semibold text-sm whitespace-nowrap transition-colors flex items-center gap-2 ${
            activeTab === 'cotizacion' 
              ? 'border-b-2 border-blue-600 text-blue-600 -mb-0.5' 
              : 'text-gray-600 hover:text-blue-600'
          }`}
        >
          <FileText className="w-4 h-4" /> Cotizar
        </button>
        {isAdmin && (
          <button
            onClick={() => setActiveTab('admin')}
            className={`px-4 py-2 font-semibold text-sm whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'admin' 
                ? 'border-b-2 border-red-600 text-red-600 -mb-0.5' 
                : 'text-gray-600 hover:text-red-600'
            }`}
          >
            <Wrench className="w-4 h-4" /> Panel Admin
          </button>
        )}
      </div>

      {activeTab === 'precios' && (
        <>
          {/* Controls */}
          <div className="mb-6 p-4 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="iva"
                  checked={showIVA}
                  onChange={(e) => setShowIVA(e.target.checked)}
                  className="w-5 h-5 md:w-4 md:h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500 bg-white"
                />
                <label htmlFor="iva" className="text-sm font-medium cursor-pointer select-none">Incluir IVA 16%</label>
              </div>
              
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-gray-500" />
                <input
                  type="text"
                  placeholder="Buscar concepto..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1 px-3 py-2 md:py-1.5 border border-gray-300 rounded text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                />
              </div>

              <div className="col-span-1 md:col-span-2">
                <label className="text-xs font-semibold text-gray-600 mb-1 block">Modo de visualización:</label>
                <div className="grid grid-cols-2 md:flex gap-2">
                  <button
                    onClick={() => setShowPricing('base')}
                    className={`px-3 py-2 md:py-1.5 rounded text-xs font-medium transition-colors ${
                      showPricing === 'base' ? 'bg-gray-700 text-white' : 'bg-white border border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Precio Base
                  </button>
                  <button
                    onClick={() => setShowPricing('minimo')}
                    className={`px-3 py-2 md:py-1.5 rounded text-xs font-medium transition-colors ${
                      showPricing === 'minimo' ? 'bg-orange-600 text-white' : 'bg-white border border-orange-300 hover:bg-orange-50'
                    }`}
                  >
                    Mínimo (+10%)
                  </button>
                  <button
                    onClick={() => setShowPricing('sugerido')}
                    className={`px-3 py-2 md:py-1.5 rounded text-xs font-medium transition-colors ${
                      showPricing === 'sugerido' ? 'bg-green-600 text-white' : 'bg-white border border-green-300 hover:bg-green-50'
                    }`}
                  >
                    Sugerido (+25%)
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Pricing Strategy Alert */}
          <div className="mb-6 p-4 bg-blue-50 border-l-4 border-blue-500 rounded">
            <div className="flex items-start gap-3">
              <TrendingUp className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-bold text-sm text-blue-900 mb-1">Estrategia de Precios</h3>
                <div className="text-xs text-blue-800 space-y-1">
                  <div><strong>Precio Base:</strong> Costo interno (nunca vender a este precio)</div>
                  <div><strong>Precio Mínimo (+10%):</strong> Solo para clientes corporativos/volumen o situaciones especiales</div>
                  <div><strong>Precio Sugerido (+25%):</strong> Precio estándar recomendado para todos los clientes</div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 1: Planes */}
          <div className="mb-6">
            <h2 className="text-lg font-bold mb-3 pb-2 border-b-2 border-blue-500">1. Planes y Suscripciones</h2>
            <TableSection 
              data={data.planes}
              color="border-blue-400"
              searchTerm={searchTerm}
              showPricing={showPricing}
              showIVA={showIVA}
              calcPrice={calcPrice}
            />
          </div>

          {/* Section 2: Costos Únicos */}
          <div className="mb-6">
            <h2 className="text-lg font-bold mb-3 pb-2 border-b-2 border-green-500">2. Costos Únicos</h2>
            
            <TableSection 
              subcategory="Servicios de Instalación y Programación"
              data={data.costosUnicos.servicios}
              color="border-green-400"
              icon={Wrench}
              searchTerm={searchTerm}
              showPricing={showPricing}
              showIVA={showIVA}
              calcPrice={calcPrice}
            />
            
            <TableSection 
              subcategory="Equipos GPS"
              data={data.costosUnicos.equipo}
              color="border-green-400"
              icon={Package}
              searchTerm={searchTerm}
              showPricing={showPricing}
              showIVA={showIVA}
              calcPrice={calcPrice}
            />
            
            <TableSection 
              subcategory="Depósitos de Garantía"
              data={data.costosUnicos.depositos}
              color="border-green-400"
              icon={Shield}
              searchTerm={searchTerm}
              showPricing={showPricing}
              showIVA={showIVA}
              calcPrice={calcPrice}
            />
            
            <TableSection 
              subcategory="Cargos por Robo"
              data={data.costosUnicos.robo}
              color="border-green-400"
              icon={AlertCircle}
              searchTerm={searchTerm}
              showPricing={showPricing}
              showIVA={showIVA}
              calcPrice={calcPrice}
            />
          </div>

          {/* Section 3: Add-ons */}
          <div className="mb-6">
            <h2 className="text-lg font-bold mb-3 pb-2 border-b-2 border-orange-500">3. Add-ons y Servicios Opcionales</h2>
            
            <TableSection 
              subcategory="Accesorios"
              data={data.addons.accesorios}
              color="border-orange-400"
              icon={Zap}
              searchTerm={searchTerm}
              showPricing={showPricing}
              showIVA={showIVA}
              calcPrice={calcPrice}
            />
            
            <TableSection 
              subcategory="Servicios de Instalación de Accesorios"
              data={data.addons.servicios}
              color="border-orange-400"
              icon={Wrench}
              searchTerm={searchTerm}
              showPricing={showPricing}
              showIVA={showIVA}
              calcPrice={calcPrice}
            />
          </div>

          {/* Critical Notes */}
          <div className="mt-8 p-5 bg-red-50 border-l-4 border-red-500 rounded">
            <div className="flex items-start gap-3 mb-3">
              <AlertCircle className="w-6 h-6 text-red-600 mt-0.5 flex-shrink-0" />
              <h3 className="font-bold text-base text-red-900">⚠️ Notas Críticas para Ventas</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <h4 className="font-semibold text-red-800 mb-2">Incluido en TODOS los planes:</h4>
                <ul className="space-y-1 text-red-700 ml-4">
                  <li>✓ SIM de datos con cobertura MX y USA</li>
                  <li>✓ Equipo GPS 4G en comodato (excepto mensual)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-red-800 mb-2">Diferencias clave:</h4>
                <ul className="space-y-1 text-red-700 ml-4">
                  <li>• <strong>Track:</strong> Plataforma web + app móvil</li>
                  <li>• <strong>Safe:</strong> Solo app móvil (sin plataforma)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-red-800 mb-2">Instalación:</h4>
                <ul className="space-y-1 text-red-700 ml-4">
                  <li>• Tijuana: $500 MXN (GRATIS 5+ unidades)</li>
                  <li>• Fuera de Tijuana: consultar viáticos</li>
                  <li>• Plan mensual: $900 MXN (sin descuento)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-red-800 mb-2">Descuentos especiales:</h4>
                <ul className="space-y-1 text-red-700 ml-4">
                  <li>• Migraciones Track: 30% desc. primera vez</li>
                  <li>• Renovaciones migración: 20% desc.</li>
                  <li>• Equipos 2G/3G: cargo extra integración</li>
                </ul>
              </div>
            </div>
          </div>
        </>
      )}
      
      {activeTab === 'compatibilidad' && (
        <div className="space-y-6">
          <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
            <h3 className="font-bold text-blue-900 mb-2 flex items-center gap-2">
              <Package className="w-5 h-5" /> Matriz de Compatibilidad
            </h3>
            <p className="text-sm text-blue-800">
              Cruza el <strong>Modelo de GPS</strong> (Filas) con los <strong>Accesorios</strong> (Columnas) para verificar compatibilidad.
            </p>
          </div>

          <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm pb-2">
            <table className="w-full text-sm text-left border-collapse min-w-[800px]">
              <thead>
                <tr className="bg-blue-600 text-white">
                  <th className="p-3 font-bold border-b border-blue-700 sticky left-0 bg-blue-600 min-w-[150px] z-10">
                    Modelo / Equipo GPS
                  </th>
                  {matrixColumns.map((col, idx) => (
                    <th key={idx} className="p-3 font-semibold text-center border-b border-blue-700 min-w-[80px]">
                      {col.label}
                    </th>
                  ))}
                  <th className="p-3 font-bold border-b border-blue-700 min-w-[200px]">
                    Limitaciones Técnicas
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white">
                {Object.entries(compatibilityMatrix).map(([equipo, info], idx) => (
                  <tr key={idx} className={`hover:bg-blue-50 ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}`}>
                    <td className="p-3 font-semibold text-slate-800 border-r border-gray-200 sticky left-0 bg-inherit z-10">
                      {equipo}
                    </td>
                    
                    {matrixColumns.map((col, colIdx) => {
                      const isCompatible = checkCompatibility(info.accesorios, col.keyword);
                      return (
                        <td key={colIdx} className="p-3 text-center border-r border-gray-100">
                          {isCompatible ? (
                            <div className="flex justify-center">
                              <span className="bg-green-100 text-green-700 p-1 rounded-full">
                                <Check className="w-4 h-4" strokeWidth={3} />
                              </span>
                            </div>
                          ) : (
                            <div className="flex justify-center">
                              <span className="text-gray-300">
                                —
                              </span>
                            </div>
                          )}
                        </td>
                      );
                    })}
                    
                    <td className="p-3 text-xs text-slate-500">
                      <div className="flex items-start gap-1">
                        {info.limitaciones !== 'Compatible con todos los accesorios' && info.limitaciones !== 'Paquete completo' && (
                          <AlertCircle className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                        )}
                        <span>{info.limitaciones}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'cotizacion' && (
        <div className="animate-in fade-in duration-300">
          <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500 mb-6">
            <h3 className="font-bold text-blue-900 mb-1">Formulario de Cotización</h3>
            <p className="text-sm text-blue-800">
              Llena los datos a continuación para generar una solicitud formal.
            </p>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex justify-center">
            <iframe 
              aria-label='¡Cotiza con nosotros!' 
              frameBorder="0" 
              style={{ height: '1000px', width: '99%', border: 'none' }} 
              src='https://forms.zohopublic.com/locjack/form/Cotizaconnosotros/formperma/tyUF0DRT5coac9F8iRVaS_ZEvZ78KcPvYcZvCAgs1Wo'
              title="Formulario de Cotización"
            ></iframe>
          </div>
        </div>
      )}

      {activeTab === 'admin' && isAdmin && (
        <div className="space-y-6 animate-in fade-in duration-300 pb-20 md:pb-16">
          <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-500 flex flex-col md:flex-row md:justify-between md:items-center gap-4">
            <div>
              <h3 className="font-bold text-red-900 mb-1 flex items-center gap-2">
                <Wrench className="w-5 h-5" /> Editor Maestro de Inventario
              </h3>
              <p className="text-sm text-red-800">
                Tiene <strong>control total</strong>. Puede agregar nuevos paquetes, eliminar obsoletos o editar descripciones y precios.
              </p>
            </div>
            <button 
              onClick={resetToDefaults}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-white border border-red-200 text-red-700 rounded-lg hover:bg-red-100 text-sm font-medium shadow-sm w-full md:w-auto"
            >
              <RotateCcw className="w-4 h-4" /> Restaurar Valores de Fábrica
            </button>
          </div>

          <div className="space-y-8">
             {/* Planes Editor */}
             <AdminSectionEditor 
                title="1. Planes y Suscripciones" 
                items={data.planes} 
                onUpdateList={(newItems) => {
                  const newData = { ...data, planes: newItems };
                  updateDataState(newData);
                }}
             />

             {/* Costos Unicos */}
             <div className="space-y-6">
                <h2 className="text-lg font-bold text-gray-700 border-b pb-2">2. Costos Únicos</h2>
                <AdminSectionEditor 
                  title="Servicios de Instalación" 
                  items={data.costosUnicos.servicios} 
                  onUpdateList={(newItems) => {
                    const newData = { ...data, costosUnicos: { ...data.costosUnicos, servicios: newItems } };
                    updateDataState(newData);
                  }}
                />
                <AdminSectionEditor 
                  title="Hardware (Equipos GPS)" 
                  items={data.costosUnicos.equipo} 
                  onUpdateList={(newItems) => {
                    const newData = { ...data, costosUnicos: { ...data.costosUnicos, equipo: newItems } };
                    updateDataState(newData);
                  }}
                />
                <AdminSectionEditor 
                  title="Depósitos de Garantía" 
                  items={data.costosUnicos.depositos} 
                  onUpdateList={(newItems) => {
                    const newData = { ...data, costosUnicos: { ...data.costosUnicos, depositos: newItems } };
                    updateDataState(newData);
                  }}
                />
                <AdminSectionEditor 
                  title="Cargos por Robo" 
                  items={data.costosUnicos.robo} 
                  onUpdateList={(newItems) => {
                    const newData = { ...data, costosUnicos: { ...data.costosUnicos, robo: newItems } };
                    updateDataState(newData);
                  }}
                />
             </div>

             {/* Addons */}
             <div className="space-y-6">
                <h2 className="text-lg font-bold text-gray-700 border-b pb-2">3. Add-ons y Accesorios</h2>
                <AdminSectionEditor 
                  title="Accesorios (Hardware)" 
                  items={data.addons.accesorios} 
                  onUpdateList={(newItems) => {
                    const newData = { ...data, addons: { ...data.addons, accesorios: newItems } };
                    updateDataState(newData);
                  }}
                />
                <AdminSectionEditor 
                  title="Servicios de Add-ons" 
                  items={data.addons.servicios} 
                  onUpdateList={(newItems) => {
                    const newData = { ...data, addons: { ...data.addons, servicios: newItems } };
                    updateDataState(newData);
                  }}
                />
             </div>
          </div>
          
          <div className="fixed bottom-6 right-6 z-20">
            <div className="bg-gray-800 text-white px-5 py-3 rounded-full shadow-xl flex items-center gap-3 animate-in slide-in-from-bottom-5">
              <Save className="w-5 h-5 text-green-400" />
              <div className="flex flex-col">
                <span className="text-xs text-gray-400">Estado del Sistema</span>
                <span className="font-bold text-sm">Guardado Automático Activo</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}