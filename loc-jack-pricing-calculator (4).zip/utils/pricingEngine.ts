import { PricingLevel } from '../types';

export const getPriceMultiplier = (level: PricingLevel): number => {
  switch (level) {
    case PricingLevel.LEVEL_1_FLOOR:
      return 1.0; // Base Internal Cost
    case PricingLevel.LEVEL_2_MIN:
      return 1.10; // +10%
    case PricingLevel.LEVEL_3_STD:
      return 1.25; // +25%
    default:
      return 1.25;
  }
};

export const calculateItemPrice = (basePrice: number, level: PricingLevel): number => {
  const multiplier = getPriceMultiplier(level);
  return Math.ceil(basePrice * multiplier);
};

export const formatCurrency = (amount: number, currency: string) => {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: currency,
  }).format(amount);
};