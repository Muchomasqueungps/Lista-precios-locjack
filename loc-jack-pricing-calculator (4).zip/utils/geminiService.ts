// Este archivo ya no es necesario en la versión estática.
// Puedes eliminarlo con seguridad.
export const generateContent = async () => { return null; };